package com.example.earthquakemonitor

object Constants {
    const val BASE_URL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/"
    const val GET_LAST_HOUR_URL = "summary/all_hour.geojson"
}