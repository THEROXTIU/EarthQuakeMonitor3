package com.example.earthquakemonitor.main

import android.app.Application
import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.*
import com.example.earthquakemonitor.Earthquake
import com.example.earthquakemonitor.api.ApiResponseStatus
import com.example.earthquakemonitor.database.getDatabase
import kotlinx.coroutines.*
import java.net.UnknownHostException
private val TAG = MainViewModel::class.java.simpleName
class MainViewModel(application: Application, private val sortType: Boolean) : AndroidViewModel(application) {
    private val database = getDatabase(application)
    private val repository = MainRepository(database)

    private val _status = MutableLiveData<ApiResponseStatus>()
    val statusLiveData: LiveData<ApiResponseStatus>
        get() = _status

    private var _eqlist = MutableLiveData<MutableList<Earthquake>>()
    val eqList: LiveData<MutableList<Earthquake>>
        get() = _eqlist

    init {
        reloadEarthquakesFromDatabase(sortType)
    }


    private fun reloadEarthquakes(sortByMagnitude: Boolean) {
        viewModelScope.launch {
            try {
                _status.value = ApiResponseStatus.LOADING
                _eqlist.value= repository.fetchEarthquakes(sortType)
                _status.value = ApiResponseStatus.DONE
            } catch (e: UnknownHostException) {
                _status.value = ApiResponseStatus.ERROR
                Log.d(TAG, "No Internet connection", e)
            }
        }
    }
    fun reloadEarthquakesFromDatabase(sortByMagnitude: Boolean) {
        viewModelScope.launch {
            _eqlist.value= repository.fetchEarthquakesFromDb(sortByMagnitude)
            if (_eqlist.value!!.isEmpty()){
                reloadEarthquakes()
                }

        }
    }
}